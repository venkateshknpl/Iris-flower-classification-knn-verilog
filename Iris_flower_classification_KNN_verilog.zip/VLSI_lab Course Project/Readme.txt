Iris_Flower_Classification_KNN video link:

https://drive.google.com/drive/folders/16TaIjcEgcMNjwqhR_cT4l_fkGk2aS1ZY?usp=sharing

Report:
------------------------
project_IRIS_Flower_Classification_KNN_report


Verilog Code:
-------------------
Iris Flower verilog code file contains the three sub-folders

1. Labsland implementation---> It contains the codes for labsland implementation
2. NioS implementation    ---> It contains the verilog code for De0-Nano board implementation.
3. RTL and Gate level simulation---> This file contains the codes for RTL and gate level simulations.

Python code:
------------
Iris_flower_training_python----> This file contains the Python training and correspnding dataset